const quizIdLocation = document.getElementById('quizData')

const joinBtn = document.getElementById('join')

joinBtn.addEventListener('click', () => {
    const quizId= quizIdLocation.value;
    window.location.href = `quiz.html?id=${quizId}`;
})
