
function initComportement() {
    let scrore_fiabilite = 40;
    let sortie = 0;
    let derniereSortie = null;
    let total_time_outside_tab = 0;
    let nbrTab = 0;

    // sort de la l'onglet (pas du navigateur)
document.addEventListener('mouseleave', e => {
    if (e.clientY <= 0) {
        console.log("La souris quitte la page");
        sortie++;
        console.log(`Nombre de sorties: ${sortie}`);
        scrore_fiabilite = scrore_fiabilite -2; 
        verifierFiabilite();
    }
});


// Empêcher de copier l'énoncé
document.addEventListener('DOMContentLoaded', function() {
var enonce = document.getElementById('enonce');
if (enonce) {
    enonce.onselectstart = function() {
        return false;
    };
}

    // Désactiver le clic droit
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // Désactiver le collage
    document.addEventListener('paste', function(event) {
        event.preventDefault();
    });

    // Réinitialiser le champ de réponse à chaque saisie
    const textareaReponse = document.querySelector('#reponse textarea');
    textareaReponse.addEventListener('input', function() {
        this.value = '';
    });

    verifierFiabilite();   
});
 
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        scrore_fiabilite = scrore_fiabilite -4
        nbrTab ++;
        verifierFiabilite();
        console.log('L\'utilisateur a changé d\'onglet ou minimisé la fenêtre.');
        derniereSortie = Date.now();
    } else {
        console.log('L\'utilisateur est revenu sur l\'onglet actif.');
        if (derniereSortie) {
            const dureeAbsence = Date.now() - derniereSortie;
            console.log(`L\'utilisateur était absent pendant ${dureeAbsence / 1000} secondes.`);
            total_time_outside_tab += dureeAbsence;
            console.log(`Le temps total passé hors de l'onglet est de ${total_time_outside_tab / 1000} secondes.`);
            derniereSortie = null;
        }
    }
});

}
   /** Section  enregistrement du comportement */

   const nomInput = document.getElementById("nom");
   const prenomInput = document.getElementById("prenom");
   const submitButton = document.getElementById("button");

//envoier le comportement
submitButton.addEventListener("click", async () => {

   const nom = nomInput.value;
   const prenom = prenomInput.value;
   console.log(scrore_fiabilite);
   if (!id_eleve) {
       alert("Veuillez d'abord vous identifier.");
       return;}

   try {
       // Utiliser id_eleve obtenu précédemment
       await enregistrerComportement(nom, prenom, sortie, nbrTab, total_time_outside_tab, scrore_fiabilite, id_eleve);
       console.log('Comportement enregistré avec succès.');
   } catch (error) {
       console.error('Erreur lors de l\'enregistrement du comportement :', error);
   }
});

   

   // enregistrer le comportement dans la base de donneees
   async function enregistrerComportement(nom, prenom, sortie, nbrTab, total_time_outside_tab , scrore_fiabilite , id_eleve) {
           const data = {
               Nom: nom,
               Prenom: prenom,
               mousleave: sortie,
               new_tab: nbrTab,
               new_tab_time: total_time_outside_tab / 1000,
               score  : scrore_fiabilite , 
               id_eleve : id_eleve
           };
   
           const response = await fetch('http://localhost:3000/api/v1/add', {
               method: 'POST',
               headers: {
                   'Content-Type': 'application/json'
               },
               body: JSON.stringify(data)
           });
   

   }
//verifier le score  de fiabilite
function verifierFiabilite() {
   if (scrore_fiabilite <= 0) {
       afficherPop();
   }
}

export {enregistrerComportement , verifierFiabilite , initComportement}