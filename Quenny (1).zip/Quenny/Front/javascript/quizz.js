// extraire les paramètres d'une URL
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}


async function getQuizData(quizId) {
    try {
        // Appel à la route backend pour récupérer les données du quiz à partir de l'ID
        const response = await fetch(`http://localhost:3000/api/v1/quizData?quizId=${quizId}`);
        
        if (!response.ok) {
            throw new Error('La requête n\'a pas abouti.');
        }

        // Conversion de la réponse en format JSON
        const data = await response.json();

        // Décoder les données récupérées depuis Supabase
        const decodedData = JSON.parse(decodeURIComponent(data[0].partage));

        // Affichage des données du quiz dans la console
        console.log("Données du quiz:", decodedData);
        
        // Retourne les données du quiz
        return decodedData;
    } catch (error) {
        console.error('Erreur lors de la récupération des données du quiz:', error);
    }
}

window.onload = async function() {
    const quizId = getParameterByName('id');
    const quizData = await getQuizData(quizId);
    
    // Maintenant, vous avez les données du quiz, vous pouvez les utiliser pour construire le quiz dans le HTML
    const { quizName, questions } = quizData;
    const quizContainer = document.getElementById('quizQuestions');
  
    const quizNameElement = document.getElementById('quizName');
    quizNameElement.textContent = quizName;
    quizContainer.insertBefore(quizNameElement, quizContainer.firstChild); // Insérer avant le premier enfant de quizContainer

    // Afficher chaque question dans le quiz
    questions.forEach((question, index) => {
        const questionElement = document.createElement('section');
        questionElement.classList.add('question');
        questionElement.innerHTML = `
            <div class="enonce">
                <p class="intitule" id="question${index + 1}">Question ${index + 1}: ${question}</p>
            </div>
            <div id="reponse">
                <textarea rows="3" name="reponse${index + 1}"></textarea>
            </div>
        `;
        quizContainer.appendChild(questionElement);
    });
};


window.onload = async function() {
    const quizId = getParameterByName('id');
    const quizData = await getQuizData(quizId);
    
    // Maintenant, vous avez les données du quiz, vous pouvez les utiliser pour construire le quiz dans le HTML
    const { quizName, questions } = quizData;
    const quizContainer = document.getElementById('quizQuestions');
  
    const quizNameElement = document.getElementById('quizName');
    quizNameElement.textContent = quizName;
    quizContainer.insertBefore(quizNameElement, quizContainer.firstChild); // Insérer avant le premier enfant de quizContainer

    // Afficher chaque question dans le quiz
    questions.forEach((question, index) => {
        const questionElement = document.createElement('section');
        questionElement.classList.add('question');
        questionElement.innerHTML = `
            <div class="enonce">
                <p class="intitule" id="question${index + 1}">Question ${index + 1}: ${question}</p>
            </div>
            <div id="reponse">
                <textarea rows="3" name="reponse${index + 1}"></textarea>
            </div>
        `;
        quizContainer.appendChild(questionElement);
    });
};

