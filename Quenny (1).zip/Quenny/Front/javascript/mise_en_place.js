
/**
 * Idée : un indice de fiabilité du rendu qui dependrait du comportement  des élèves , 
  on peut donner des poids aux traqueurs par empemple copier l'énoncé  c'est tres suspect alors  que changer d'onglets ça l'est un peu moins . quand l'eleve remet qq chose 
  son rendu est accompagné d'un "syntese" qui dit par exemple , il a changé tant de fois d'onglets , il a copier tel truc , coller tel truc , peu fiable , suspect , trciherie certaine

 */
