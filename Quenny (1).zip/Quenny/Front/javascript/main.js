import { initIdentification } from "./identification";
import { initComportement , enregistrerComportement , verifierFiabilite } from "./comportement";

function main() {
    initIdentification();
    initComportement();
    enregistrerComportement();
    verifierFiabilite();   
}




document.addEventListener("DOMContentLoaded", main);
