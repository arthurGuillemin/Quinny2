// Sélectionnez les éléments du formulaire
const bouton = document.getElementById('button');

function afficherFormulaire() {
    var sectionAjout = document.getElementById("ajout");
    sectionAjout.innerHTML = ""; // Effacer le contenu précédent

    var form = document.createElement("form");

    var inputNomClasse = document.createElement("input");
    inputNomClasse.type = "text";
    inputNomClasse.placeholder = "Nom de la classe";
    inputNomClasse.required = true;
    inputNomClasse.name = "nomClasse";

    var divEleves = document.createElement("div"); // Div pour les champs d'élèves

    var inputNomEleve = document.createElement("input");
    inputNomEleve.type = "text";
    inputNomEleve.placeholder = "Nom de l'élève";
    inputNomEleve.required = true;
    inputNomEleve.name = "nomsEleves[]"; // Ajout d'un tableau de noms pour les élèves

    var boutonAjouterEleve = document.createElement("button");
    boutonAjouterEleve.textContent = "Ajouter un élève";
    boutonAjouterEleve.type = "button"; // Change le type pour éviter l'envoi du formulaire lorsqu'on clique
    boutonAjouterEleve.onclick = function() {
        var inputEleve = document.createElement("input");
        inputEleve.type = "text";
        inputEleve.placeholder = "Nom de l'élève";
        inputEleve.required = true;
        inputEleve.name = "nomsEleves[]"; // Ajout d'un tableau de noms pour les élèves
        divEleves.appendChild(inputEleve);
        divEleves.appendChild(document.createElement("br")); // Ajout d'un saut de ligne entre les champs
    };

    var boutonCreerClasse = document.createElement("button");
    boutonCreerClasse.textContent = "Créer la classe";
    boutonCreerClasse.type = "submit";

    form.appendChild(inputNomClasse);
    form.appendChild(document.createElement("br"));
    form.appendChild(inputNomEleve);
    form.appendChild(document.createElement("br"));
    form.appendChild(divEleves); // Ajout du div contenant les champs d'élèves
    form.appendChild(boutonAjouterEleve);
    form.appendChild(document.createElement("br"));
    form.appendChild(boutonCreerClasse);

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Empêcher l'envoi du formulaire
        let nom_classe = inputNomClasse.value;
        const nomsEleves = Array.from(document.querySelectorAll("[name='nomsEleves[]']")).map(input => input.value);
        createClasse(nom_classe); // Passer les données du formulaire à la fonction createTable()
    });

    sectionAjout.appendChild(form);
}

// Fonction pour créer la classe avec les élèves sur le serveur
async function createClasse(nom_classe) {
    try {
        const response = await fetch('http://localhost:3000/api/v1/addClasse', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ nom_classe }) // Passer les données du formulaire
        });
        if (response.ok) {
            console.log('Classe ajoutée avec succès.');
        } else {
            console.error('Erreur lors de l\'ajout de la classe:', response.statusText);
        }
    } catch (error) {
        console.error('Erreur lors de l\'ajout de la classe:', error.message);
    }
}