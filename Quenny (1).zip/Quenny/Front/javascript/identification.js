function initIdentification() {
    const identifierBtn = document.getElementById("identifier");
    let id_eleve;

    identifierBtn.addEventListener("click", async () => {
        const nom = nomInput.value.trim(); 
        const prenom = prenomInput.value.trim(); 
    
        try {
            const response = await fetch(`http://localhost:3000/api/v1/idEleve?nom=${nom}&prenom=${prenom}`);
            const data = await response.json();
    
            if (data.id_eleve) {
                id_eleve = data.id_eleve; 
                console.log("ID de l'élève:", data.id);   
                submitButton.disabled = false;
            }
        } catch (error) {
            console.error("Erreur lors de la récupération de l'ID de l'élève:", error);
            alert("Une erreur s'est produite lors de la récupération de l'ID de l'élève. Veuillez réessayer plus tard.");
        }
    });
}

export {initIdentification}