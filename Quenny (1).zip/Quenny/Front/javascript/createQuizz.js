let questions = [];
let addQuestionBtn =  document.querySelector("#addQuestion");
let createBtn = document.getElementById('create')
let validerBtn = document.getElementById('nameV')
let quizName; 
let quizData;

async function getQuizID() {
    try {
        
        // Appel à la route backend pour récupérer l'ID du quiz à partir de son nom
        const response = await fetch(`http://localhost:3000/api/v1/quizId?quizName=${quizName}`);
        
        if (!response.ok) {
            throw new Error('La requête n\'a pas abouti.');
        }

        // Conversion de la réponse en format JSON
        const data = await response.json();
        let quizId = data[0];
        
        // Affichage de l'ID du quiz dans la console
        console.log("ID du quiz:", quizId);
        
        // Retourne l'ID du quiz
        return quizId;
    } catch (error) {
        console.error('Erreur lors de la récupération de l\'ID du quiz:', error);
    }
};

addQuestionBtn.addEventListener("click", function (){
    ajouterQuestion();
})
createBtn.addEventListener('click', async function(){
    // Récupérer quizData depuis creerQuiz()
    quizData = await creerQuiz();
    createQuiz(quizData);
})


// ajouter une question
function ajouterQuestion() {
    const container = document.getElementById('questionsContainer');
    const questionNumber = questions.length + 1;
    const questionInput = document.createElement('div');
    questionInput.innerHTML = `
        <section class="creatquestion">
            <div class="enonce">
                <p id="question${questionNumber}">Question ${questionNumber} :</p>
            </div>
            <div id="reponse">
                <textarea rows="3" name="question${questionNumber}"></textarea>
            </div>
        </section>
    `;
    container.appendChild(questionInput);
}

// creer le quiz
async function creerQuiz() {
    questions = []; 
    const form = document.getElementById('quizForm');
    const inputs = form.getElementsByTagName('textarea');
    const quizName = document.getElementById('quizName').value;

    // parcours des champs de texte et stockage des questions dans le tableau
    for (let i = 0; i < inputs.length; i++) {
        if (inputs[i].value.trim() !== '') {
            questions.push(inputs[i].value.trim());
        }
    }
    let quizData = encodeURIComponent(JSON.stringify({ quizName, questions }));
    const quizLink = `Lien à partager avec vos apprenants :${quizData}`;
        
    // Affichage du lien dans l'élément HTML
    document.getElementById('quizLink').innerHTML = quizLink;

    // Retourner quizData
    return quizData;
}




async function createQuiz(){
    try {
        quizData = await creerQuiz();
        // Récupération du nom du quiz à partir de l'élément HTML correspondant
        const quizName = document.getElementById('quizName').value;
        console.log(`quizName ${quizName}`);
        console.log(`quizData : ${quizData}`);

        // Envoi d'une requête POST à la route backend pour créer un nouveau quiz
        const response = await fetch('http://localhost:3000/api/v1/createQuiz', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ quizName , quizData })
        });

        if (!response.ok) {
            throw new Error('La requête n\'a pas abouti.');
        }

        // Affichage d'un message de succès après la création du quiz
        console.log("Quiz créé avec succès:", quizName , quizData);

       
    } catch (error) {
        console.error(error);
    }
};