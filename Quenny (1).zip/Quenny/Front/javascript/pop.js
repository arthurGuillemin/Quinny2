// popuptriche
function afficherPop() {
    const popUpBackground = document.createElement('div');
    popUpBackground.classList.add('popup-background');
    const popUpDiv = document.createElement('div');
    popUpDiv.classList.add('popup');
    
    popUpDiv.innerHTML = `
        <div class="popup-content">
            <h2>Tentative de Trcihe detectée </h2>
            <p>Vous ne pouvez plus effectuer d'actions sur cette page.</p>
        </div>
    `;
    
    document.body.appendChild(popUpBackground);
    document.body.appendChild(popUpDiv);
 }
 
 